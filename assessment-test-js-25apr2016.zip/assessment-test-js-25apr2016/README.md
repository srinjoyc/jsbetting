Sinatra
=============

Brought to you by Lighthouse Labs

## Getting Started

1. `bundle install`
2. `shotgun -p 3000 -o 0.0.0.0`
3. Visit `http://localhost:3000/` in your browser
4. Please edit only the view files. There is no need to edit the actions.rb.
5. You have two hours to complete the test.

