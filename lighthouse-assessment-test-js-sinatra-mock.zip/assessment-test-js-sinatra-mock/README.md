Sinatra
=============

Brought to you by Lighthouse Labs

## Getting Started

1. `bundle install`
2. `bundle exec rake db:setup`
3. `shotgun -p 3000 -o 0.0.0.0`
4. Visit `http://localhost:3000/` in your browser
5. Please edit only the view files. There is no need to edit the actions.rb.
6. You have two hours to complete the test.

