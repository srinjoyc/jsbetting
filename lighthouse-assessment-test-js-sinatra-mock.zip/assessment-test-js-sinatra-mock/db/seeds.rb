Question.create points: 10
Question.create points: 10
Question.create points: 15
Question.create points: 10
Question.create points: 15
Question.create points: 15
Question.create points: 15
Question.create points: 10

